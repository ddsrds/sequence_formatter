🧬 Formatador de Sequência Genética

O script tem como objetivo reformatar arquivos de sequência genética (como os arquivos .fasta ou .txt) da seguinte forma:

- Preserva o cabeçalho original (linha que começa com '>').
- Une todas as linhas subsequentes da sequência em uma única linha contínua, facilitando a leitura e o processamento da sequência por outros programas.

📁 Etapas para utilizar o script

1. Salvar o script e o arquivo da sequência

- Crie uma nova pasta no seu Google Drive.
- Salve este script dentro dessa pasta.
- Salve o arquivo de sequência, ou seja, o arquivo que deseja organizar na mesma pasta em que esta o script.
- Importante: renomeie o arquivo da sequência para "sequencia.txt".

2. Abrir o script no Google Colab

- Clique com o botão direito no arquivo do script (ex: sequence_formatter.ipynb) e selecione "Abrir com > Google Colab".
- O Colab será aberto em uma nova aba do navegador com o conteúdo do script carregado.

3. Editar os caminhos dos arquivos

No segundo bloco de código, você encontrará duas linhas importantes no início:

    entrada = '/content/drive/MyDrive/NomeDaPastaCriada/sequencia.txt'
    saida = '/content/drive/MyDrive/NomeDaPastaCriada/saida.txt'

- Altere o caminho da variável entrada para refletir o local exato onde você salvou o arquivo no seu Drive (sequencia.txt).
- Altere o caminho da variável saida para o local onde deseja salvar o arquivo de saída (saida.txt).

Dica: você pode navegar no lado esquerdo do Colab (ícone de pastinha 📁) para explorar os diretórios e copiar o caminho da pasta desejada.

4. Permitir acesso ao Google Drive

Para que o script consiga acessar os arquivos que estão salvos no seu Google Drive, é necessário conectar o Google Colab à sua conta do Drive. Siga os passos abaixo:

- Com o script aberto no Google Colab use o comando "CTRL + F9" para executar o codigo de todos os blocos.
- O Colab pedirá permissão para acessar seu Google Drive.
- Após o login, será gerada uma tela pedindo autorização para acessar os arquivos do seu Google Drive.
- Clique na opção para autorizar o acesso e agora seu Google Drive estará montado no ambiente do Colab.

5. Verificar o arquivo de saída

- Acesse a pasta onde estão os arquivos no seu Google Drive.
- O novo arquivo organizado deverá aparecer como: saida.txt
- Se ele não aparecer de imediato, atualize a página do Drive algumas vezes, pois o Google Drive pode demorar alguns segundos para exibir arquivos criados por scripts do Colab.

6. Possiveis erros

- O script não modifica os dados genéticos, apenas reorganiza o formato da sequência, mas para evitar erros certifique-se de que:
    - Esteja conectado a uma rede Wi-Fi.
    - O nome do arquivo original seja exatamente sequencia.txt.
    - Os caminhos estejam corretos no script.

- Em caso de mais erros tente reiniciar seu navegador ou seu computador.
